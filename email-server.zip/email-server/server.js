const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors({
  origin: '*',
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_ADDRESS,
    pass: process.env.EMAIL_APP_PASSWORD
  }
});

transporter.verify((error) => {
  if (error) {
    console.error('❌ Email transporter verification failed:', error);
  } else {
    console.log('✅ Email transporter ready to send emails');
  }
});

const emailTemplates = {
  submitted: (fullName) => ({
    subject: 'Your Candidacy Application Has Been Submitted',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; text-align: justify;">
        <h2 style="color: #5A7FDB; margin-bottom: 10px;">Candidacy Application Received</h2>

        <p>Dear ${fullName},</p>

        <p>Thank you for your interest in serving the student body and taking the first step toward becoming a student leader.</p>

        <p>This message confirms that your candidacy application for the upcoming Student Council Elections has been <strong>successfully submitted</strong> to the Commission on Student Elections and Appointments (COMSELECA).</p>

        <p>Our team will now carefully review your submitted documents. You will receive another email notification once the assessment of your application has been reviewed.</p>

        <p>If you have any concerns or questions, feel free to contact us through <a href="mailto:comseleca@mcc.edu.ph">comseleca@mcc.edu.ph</a>.</p>

        <p >Very truly yours,<br>
        MCC – COMSELECA
        </p>
      </div>
    `
  }),

  reviewed: (fullName) => ({
    subject: 'Candidacy Application Status',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; text-align: justify;">
        <h2 style="color: #2c3e50;">Candidacy Application Status</h2>
        <p>Dear Mr./Ms. ${fullName},</p>
        
        <p>We hope this message finds you well. We want to express our deepest appreciation for having an interest in serving and leading our college.</p>
        
        <p>We would like to inform you that your candidacy application in the upcoming Student Council Elections has been reviewed by the Commission on Student Elections and Appointments.</p>
        
        <p>At this stage, you can now make an appointment for the screening process at <a href="https://macisanmetungca.vercel.app">https://macisanmetungca.vercel.app</a> as part of the evaluation process.</p>
        
        <p><strong>Your attendance is a must.</strong> Please bring all physical copies of your submitted requirements. Failure to attend may affect your application status.</p>
        
        <p>Should you have any questions, please contact us through <a href="mailto:comseleca@mcc.edu.ph">comseleca@mcc.edu.ph</a>.</p>
        
        <p>Very Truly Yours,<br>
        MCC – COMSELECA</p>
      </div>
    `
  }),

  passed: (fullName, position) => ({
    subject: 'Result of the Student Leader Screening Process',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; text-align: justify;">
        <h2 style="color: #27ae60;">Result of the Student Leader Screening Process</h2>
        <p>Dear Mr./Ms. ${fullName},</p>
        
        <p>We hope this message finds you well. We want to express our deepest appreciation for showing positive participation throughout the screening process and for having an interest in serving and leading our college.</p>
        
        <p>After a thorough and careful deliberation, we are delighted to extend our heartfelt congratulations to you on successfully passing the screening process to become a <strong>${position}</strong>. Your dedication, enthusiasm, and commitment to making a positive impact on our college have not gone unnoticed.</p>
        
        <p>Your accomplishment in securing this important role is a testament to your exceptional leadership qualities, integrity, and unwavering passion for representing the voices of your fellow students. Your vision for the future and your willingness to serve as a role model are truly commendable.</p>
        
        <p>Once again, congratulations on this well-deserved achievement. We look forward to witnessing the positive impact you will undoubtedly make as a student leader.</p>
        
        <p>Best wishes for a fulfilling and successful tenure ahead.</p>
        
        <p>Should you have any questions, please contact us through <a href="mailto:comseleca@mcc.edu.ph">comseleca@mcc.edu.ph</a>.</p>
        
        <p>Very Truly Yours,<br>
        MCC – COMSELECA</p>
      </div>
    `
  }),

  failed: (fullName) => ({
    subject: 'Result of the Student Leader Screening Process',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; text-align: justify;">
        <h2 style="color: #e74c3c;">Result of the Student Leader Screening Process</h2>
        <p>Dear Mr./Ms. ${fullName},</p>
        
        <p>We regret to inform you that you have not been chosen to advance as a future student leader following a thorough and rigorous screening. We want to inform you that this outcome was reached after careful consideration and evaluation.</p>
        
        <p>Regardless of the outcome, we'd like to emphasize how much we valued your application and participation in our process. May you continue to contribute to our college and community in ways that are in line with your abilities and aspirations.</p>
        
        <p>Once again, we appreciate your enthusiasm and dedication throughout the screening process.</p>
        
        <p>Best wishes for a fulfilling and successful tenure ahead.</p>
        
        <p>Should you have any questions, please contact us through <a href="mailto:comseleca@mcc.edu.ph">comseleca@mcc.edu.ph</a>.</p>
        
        <p>Very Truly Yours,<br>
        MCC – COMSELECA</p>
      </div>
    `
  })
  ,
  appointment: (fullName, _position, details) => {
    const formattedDateTime = (() => {
      try {
        if (!details?.dateTime) return ''
        return new Date(details.dateTime).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })
      } catch {
        return details?.dateTime || ''
      }
    })()
    return ({
    subject: 'Confirmation of Screening Appointment',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; text-align: justify;">
        <h2 style="color: #2c3e50;">Confirmation of Screening Appointment</h2>
        <p>Dear Mr./Ms. ${fullName},</p>
        
        <p>We hope this message finds you well. Thank you for your continued commitment to serving and leading our college.</p>
        
        <p>This email serves as confirmation that you have successfully secured an appointment for the screening process as part of your candidacy application in the upcoming Student Council Elections. Please be reminded of the following details:</p>
        
        <p><strong>Date & Time:</strong> ${formattedDateTime}</p>
        <p><strong>Venue:</strong> ${details?.venue || 'MB201 (MCC Dolores Campus)'}</p>
        <p><strong>Requirements:</strong> Bring all physical copies of your submitted documents</p>
        
        <p>Your punctuality and preparedness are highly encouraged, as this step is a vital part of the evaluation process. Failure to attend may affect your application status.</p>
        
        <p>We look forward to seeing you at your scheduled screening. Should you have any questions, please do not hesitate to reach us at <a href="mailto:comseleca@mcc.edu.ph">comseleca@mcc.edu.ph</a>.</p>
        
        <p>Very Truly Yours,<br>
        MCC – COMSELECA</p>
      </div>
    `
    })
  },
  appointmentDeclined: (fullName) => ({
    subject: 'Screening Appointment – Booking Not Approved',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; text-align: justify;">
        <h2 style="color: #e74c3c;">Screening Appointment – Booking Not Approved</h2>
        <p>Dear Mr./Ms. ${fullName},</p>

        <p>We hope this message finds you well. Thank you for your interest in the upcoming Student Council Elections.</p>

        <p>We regret to inform you that your request to book a screening appointment has not been approved. This decision was made by MCC – COMSELECA, who reserves the authority to approve or reject appointment bookings under special circumstances.</p>

        <p>Possible reasons may include:</p>
        <ul>
          <li>Your selected slot is no longer available,</li>
          <li>Your booking did not comply with the set guidelines, or</li>
          <li>COMSELECA has determined a necessary adjustment to the schedule.</li>
        </ul>

        <p>If you wish to clarify the reason for this status, you may contact us at <a href="mailto:comseleca@mcc.edu.ph">comseleca@mcc.edu.ph</a>.</p>

        <p>We encourage you to stay engaged in the election process and uphold the values of leadership and governance in our institution.</p>

        <p>Very truly yours,<br>
        MCC – COMSELECA</p>
      </div>
    `
  })
  ,
  voteThankYou: (fullName, _position) => ({
    subject: 'Thank you for voting – Student Council Elections',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; text-align: justify;">
        <h2 style="color: #2c3e50;">Thank you for voting</h2>
        <p>Dear Mr./Ms. ${fullName},</p>

        <p>The Commission on Student Elections and Appointments extends its deepest gratitude for your active participation in the recently concluded Student Council Elections.</p>

        <p>Your vote is not only a right but also a vital contribution to strengthening student democracy and leadership within our college. By casting your ballot, you have played a significant role in shaping the future of our student community and ensuring that your voice is heard.</p>

        <p>The results of the election will be released through our official channels. We encourage you to stay updated and continue supporting our elected leaders as they take on the responsibility of serving the student body.</p>

        <p>Once again, thank you for your engagement, trust, and commitment to our student government.</p>

        <p>For inquiries, please contact us at <a href="mailto:comseleca@mcc.edu.ph">comseleca@mcc.edu.ph</a>.</p>

        <p>Very Truly Yours,<br>
        MCC – COMSELECA</p>
      </div>
    `
  })
};

app.get('/', (req, res) => {
  res.json({ 
    message: 'MaCisanmetungCa Email Server is running!',
    endpoints: {
      'POST /send-email': 'Send candidacy status email',
      'GET /health': 'Health check'
    }
  });
});

app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

app.post('/send-email', async (req, res) => {
  try {
    const { to, status, fullName, position, details } = req.body;

    if (!to || !status || !fullName) {
      return res.status(400).json({ 
        error: 'Missing required fields: to, status, name' 
      });
    }

    if (!['submitted','reviewed', 'passed', 'failed', 'appointment', 'appointmentDeclined', 'voteThankYou'].includes(status)) {
      return res.status(400).json({ 
        error: 'Invalid status. Must be: reviewed, passed, failed, appointment, appointmentDeclined, or voteThankYou' 
      });
    }

    const template = emailTemplates[status](fullName, position, details);

    const mailOptions = {
      from: `"MCC - COMSELECA" <${process.env.EMAIL_ADDRESS}>`,
      to: to,
      subject: template.subject,
      html: template.html
    };

    const info = await transporter.sendMail(mailOptions);
    
    console.log('Email sent:', info.messageId);
    
    res.json({ 
      success: true, 
      messageId: info.messageId,
      message: `Email sent successfully to ${to}` 
    });

  } catch (error) {
    console.error('Error sending email:', error);
    res.status(500).json({ 
      error: 'Failed to send email',
      details: error.message 
    });
  }
});

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log('='.repeat(50));
  console.log('🚀 MaCisanmetungCa Email Server Started!');
  console.log('='.repeat(50));
  console.log(`📍 Server running on port ${PORT}`);
  console.log(`🌐 Health Check: /health`);
  console.log(`📧 Email Endpoint: /send-email`);
  console.log(`🔧 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🌍 Host: 0.0.0.0 (accessible from all interfaces)`);
  console.log('='.repeat(50));
  console.log('Ready to send emails! 📬');
});
