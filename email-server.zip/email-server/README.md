<<<<<<< HEAD
# MaCisanmetungCa Email Server

A Node.js email server for sending candidacy status notifications.

## 🚀 Quick Start

### Local Development

1. Install dependencies:
```bash
npm install
```

2. Create `.env` file with your email credentials:
```
EMAIL_ADDRESS=macisanmetungca@gmail.com
EMAIL_APP_PASSWORD=your_app_password_here
PORT=3000
```

3. Run the server:
```bash
# Development
npm run dev

# Production
npm start
```

### 🚀 Deploy to Render.com

See [DEPLOYMENT.md](./DEPLOYMENT.md) for detailed deployment instructions.

**Quick deploy:**
1. Push to GitHub
2. Connect to Render.com
3. Set environment variables
4. Deploy!

## API Endpoints

### POST /send-email
Send candidacy status email.

**Request Body:**
```json
{
  "to": "student@mcc.edu.ph",
  "status": "reviewed|passed|failed",
  "name": "Student Name",
  "position": "Position Name (required for 'passed' status)"
}
```

**Example:**
```json
{
  "to": "john.doe@mcc.edu.ph",
  "status": "reviewed",
  "name": "John Doe"
}
```

### GET /health
Health check endpoint.

## Deployment on Render.com

1. Connect your GitHub repository
2. Set environment variables in Render dashboard:
   - `EMAIL_ADDRESS`
   - `EMAIL_APP_PASSWORD`
3. Deploy!

## Email Templates

- **Reviewed**: Notifies student that application is reviewed and ready for screening
- **Passed**: Congratulates student for passing screening process
- **Failed**: Informs student they didn't pass screening process
=======
# MaCisanmetungCa Email Server

A Node.js email server for sending candidacy status notifications.

## 🚀 Quick Start

### Local Development

1. Install dependencies:
```bash
npm install
```

2. Create `.env` file with your email credentials:
```
EMAIL_ADDRESS=macisanmetungca@gmail.com
EMAIL_APP_PASSWORD=your_app_password_here
PORT=3000
```

3. Run the server:
```bash
# Development
npm run dev

# Production
npm start
```

### 🚀 Deploy to Render.com

See [DEPLOYMENT.md](./DEPLOYMENT.md) for detailed deployment instructions.

**Quick deploy:**
1. Push to GitHub
2. Connect to Render.com
3. Set environment variables
4. Deploy!

## API Endpoints

### POST /send-email
Send candidacy status email.

**Request Body:**
```json
{
  "to": "student@mcc.edu.ph",
  "status": "reviewed|passed|failed",
  "name": "Student Name",
  "position": "Position Name (required for 'passed' status)"
}
```

**Example:**
```json
{
  "to": "john.doe@mcc.edu.ph",
  "status": "reviewed",
  "name": "John Doe"
}
```

### GET /health
Health check endpoint.

## Deployment on Render.com

1. Connect your GitHub repository
2. Set environment variables in Render dashboard:
   - `EMAIL_ADDRESS`
   - `EMAIL_APP_PASSWORD`
3. Deploy!

## Email Templates

- **Reviewed**: Notifies student that application is reviewed and ready for screening
- **Passed**: Congratulates student for passing screening process
- **Failed**: Informs student they didn't pass screening process
>>>>>>> 816a80a2f05d08ee26ab66be8e88b4ada284aca5
