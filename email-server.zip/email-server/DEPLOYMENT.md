# Deploy Email Server to Render.com

## 🚀 Quick Deployment Steps

### 1. Push to GitHub
```bash
cd email-server
git init
git add .
git commit -m "Initial email server setup"
git branch -M main
git remote add origin https://github.com/yourusername/email-server.git
git push -u origin main
```

### 2. Deploy on Render.com

1. **Go to [Render.com](https://render.com)** and sign up/login
2. **Click "New +"** → **"Web Service"**
3. **Connect your GitHub repository**
4. **Configure the service:**
   - **Name**: `macisanmetungca-email-server`
   - **Environment**: `Node`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Plan**: `Free`

### 3. Set Environment Variables

In Render dashboard, go to **Environment** tab and add:

```
EMAIL_ADDRESS = macisanmetungca@gmail.com
EMAIL_APP_PASSWORD = otri xnfq mmmc mpdl
NODE_ENV = production
```

### 4. Deploy!

Click **"Create Web Service"** and wait for deployment.

## 🔗 After Deployment

Your email server will be available at:
```
https://macisanmetungca-email-server.onrender.com
```

### Test Endpoints:
- **Health Check**: `https://macisanmetungca-email-server.onrender.com/health`
- **Email API**: `https://macisanmetungca-email-server.onrender.com/send-email`

## 🔧 Update Main App

Add this to your main app's environment variables:
```
VITE_EMAIL_SERVER_URL=https://macisanmetungca-email-server.onrender.com
```

## 📝 Notes

- **Free tier**: Service sleeps after 15 minutes of inactivity
- **Cold start**: First request after sleep may take 30+ seconds
- **Upgrade**: Consider paid plan for production use
